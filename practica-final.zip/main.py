import random
import time

class Concursante:
    def __init__(self, nombre):
        self.nombre = nombre
        self.tiempo_clasificatoria = 0
        self.valor_premio = 0
        self.ultima_pregunta_correcta = 0
        self.comodines_utilizados = {'50/50': 0, 'ayuda_publico': 0, 'llamada_amigo': 0}

    def mostrar_informacion(self):
        print(f"\nInformación de {self.nombre}:")
        print(f"Tiempo de clasificación: {self.tiempo_clasificatoria} segundos")
        print(f"Valor del premio: ${self.valor_premio}")
        print(f"Última pregunta correcta: {self.ultima_pregunta_correcta}")
        print(f"Comodines utilizados: {self.comodines_utilizados}")

class ProgramaConcurso:
    def __init__(self):
        self.concursantes = []
        self.valor_total_semana = 0

    def nuevo_concursante(self, concursante):
        self.concursantes.append(concursante)

    def generar_pregunta(self, numero_pregunta):
        # En una implementación completa, las preguntas podrían cargarse desde una base de datos o archivo externo
        opciones = ['Opción A', 'Opción B', 'Opción C', 'Opción D']
        random.shuffle(opciones)
        pregunta = f"Pregunta {numero_pregunta}: ¿Cuál es la opción correcta?\n" + "\n".join(opciones)
        respuesta_correcta = opciones.index('Opción A') + 1  # La opción A es la correcta
        return pregunta, respuesta_correcta

    def realizar_concurso(self, concursante):
        print(f"\n¡Bienvenido, {concursante.nombre}! Comencemos la clasificación.")

        for numero_pregunta in range(1, 16):
            pregunta, respuesta_correcta = self.generar_pregunta(numero_pregunta)

            # Simular tiempo de respuesta
            tiempo_inicio = time.time()
            respuesta_jugador = self.obtener_respuesta_jugador(pregunta)
            tiempo_fin = time.time()
            tiempo_respuesta = tiempo_fin - tiempo_inicio

            if respuesta_jugador == respuesta_correcta:
                concursante.ultima_pregunta_correcta = numero_pregunta
                concursante.valor_premio = self.calcular_premio(numero_pregunta)
                concursante.tiempo_clasificatoria = tiempo_respuesta
                print("¡Respuesta correcta! Has avanzado a la siguiente pregunta.")
            else:
                print(f"Respuesta incorrecta. Fin del juego para {concursante.nombre}.")
                break

        self.valor_total_semana += concursante.valor_premio
        concursante.mostrar_informacion()

    def obtener_respuesta_jugador(self, pregunta):
        print("\n" + pregunta)
        print("Selecciona la opción correcta:")
        respuesta_jugador = input().strip().upper()
        while respuesta_jugador not in ['A', 'B', 'C', 'D']:
            print("Respuesta inválida. Por favor, selecciona A, B, C o D.")
            respuesta_jugador = input().strip().upper()

        return int(ord(respuesta_jugador) - ord('A')) + 1

    def calcular_premio(self, numero_pregunta):
        premios = {
            15: 300000000,
            14: 100000000,
            13: 50000000,
            12: 20000000,
            11: 12000000,
            10: 10000000,
            9: 7000000,
            8: 5000000,
            7: 3000000,
            6: 2000000,
            5: 1000000,
            4: 500000,
            3: 300000,
            2: 200000,
            1: 100000
        }
        return premios.get(numero_pregunta, 0)

    def finalizar_semana(self):
        print("\nResumen de la semana:")
        for concursante in self.concursantes:
            concursante.mostrar_informacion()
        print(f"\nValor total otorgado en la semana: ${self.valor_total_semana}")

# Ejemplo de uso
programa = ProgramaConcurso()

# Agregar concursantes con sus respectivos datos
numero_concursantes = int(input("Ingrese el número de concursantes: "))
for i in range(1, numero_concursantes + 1):
    nombre = input(f"Ingrese el nombre del concursante {i}: ")
    concursante = Concursante(nombre)
    programa.nuevo_concursante(concursante)

# Simular el concurso para cada concursante
for concursante in programa.concursantes:
    programa.realizar_concurso(concursante)

# Finalizar la semana y mostrar el informe
programa.finalizar_semana()
